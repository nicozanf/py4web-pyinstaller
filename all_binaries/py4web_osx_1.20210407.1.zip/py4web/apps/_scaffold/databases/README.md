
This is just a placeholder for the needed '_scaffold/databases' folder
