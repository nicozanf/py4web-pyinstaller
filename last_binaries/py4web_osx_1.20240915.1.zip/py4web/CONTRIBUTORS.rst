
The list in CONTRIBUTORS.rst has been moved to the end of the README.rst file
