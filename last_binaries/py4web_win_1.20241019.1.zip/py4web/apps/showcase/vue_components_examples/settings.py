from ..examples.settings import *
