import logging

from pydal.tools.tags import Tags

logging.warning(
    "Deprecation notice: replace py4web.utils.tags with pydal.tools.tags in your code."
)
